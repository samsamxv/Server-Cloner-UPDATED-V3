# Discord Server Cloner

A powerful tool to clone Discord servers quickly and efficiently.

## Features
- Clone server channels, roles, and settings.
- Fast and reliable with minimal setup.

## Requirements
- Python 3.12 or higher

## Installation & Usage

1. **Install Python 3.12**  
   Download and install Python 3.12 from [python.org](https://www.python.org/).

2. **Run the Install Script**  
   Double-click the `install.bat` file to install all necessary packages.

3. **Start the Cloner**  
   Double-click the `start.bat` file to begin cloning a server.  
   - Enter your Discord account token when prompted.  
   - Follow the on-screen instructions to complete the process.

## License
This project is licensed under the MIT License. See the [LICENSE](LICENSE) file for details.

## Disclaimer
Use this tool responsibly. The developers are not responsible for any misuse or violation of Discord's terms of service.
